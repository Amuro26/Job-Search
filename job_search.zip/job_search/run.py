# -*- coding: utf-8 -*-

from app import app, manager

app.run(debug=True)




